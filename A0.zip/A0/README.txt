This is my assignment A0

The program provides a class for a Binary Search Tree
 and these included public methods:

        void insert(int);
        void remove(int);
        void printBST();
        bool isBalanced();
        node* findNode(int);

there are also other functions that are made private,
such as:

        void printInOrder(node*);
        void printPreOrder(node*);
        void printPostOrder(node*);
        int hight(node*);
        node* findPrevNode(int);