The code in this project is for a splay tree

there are a lot of folders in this project, but each one is for
the different implementation of a splay tree. 

they are all set up to read 100000 lines of input data from a file
in the accessPattern directory, and then all of the lines after,
it will search for the values in the splay tree.

the splay trees all have the basics: insert, search, splay.
while most of them do have a functioning delete, weighted does
not. this is due to actually overriding the rotate functions.

have fun looking at this project. I hope it is everything you
have ever dreamed of...

